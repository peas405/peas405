//YouTube影片ID
let playList = [
    "otJ-c6nMZyQ",//like it is
    "3K_h-T74nxs",//attack音D
];
//播放起訖秒數
let playTime = [
    [0,178],
    [0,282]
];