let topicsArray = [
    "尚未開學",
    "國定假日",
    "環境準備",
    "隨機性",
    "重複性",
];

let stratDate = new Date();

function setMonthAndDay(startMonth, startDay) {
    stratDate.setMonth(startMonth - 1, startDay);
    stratDate.setHours(0);
    stratDate.setMinutes(0);
    stratDate.setSeconds(0);
}





