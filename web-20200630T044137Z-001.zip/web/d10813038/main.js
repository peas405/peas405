$(document).ready(function () {
    $("#yt").click(function (e) { 
        location.assign("https://www.youtube.com/watch?v=V3aU9hWv4Ic");
    });
    $("#net").click(function (e) { 
        location.assign("https://www.youtube.com/watch?v=yEIRc9BZwlU");
    });
});
